#include "RescueAnimal.h"

std::string RescueAnimal::getName() const { return name; }
void RescueAnimal::setName(const std::string& n) { name = n; }

std::string RescueAnimal::getAnimalType() const { return animalType; }
void RescueAnimal::setAnimalType(const std::string& type) { animalType = type; }

std::string RescueAnimal::getGender() const { return gender; }
void RescueAnimal::setGender(const std::string& g) { gender = g; }

std::string RescueAnimal::getAge() const { return age; }
void RescueAnimal::setAge(const std::string& a) { age = a; }

std::string RescueAnimal::getWeight() const { return weight; }
void RescueAnimal::setWeight(const std::string& w) { weight = w; }

std::string RescueAnimal::getAcquisitionDate() const { return acquisitionDate; }
void RescueAnimal::setAcquisitionDate(const std::string& date) { acquisitionDate = date; }

std::string RescueAnimal::getAcquisitionCountry() const { return acquisitionCountry; }
void RescueAnimal::setAcquisitionCountry(const std::string& country) { acquisitionCountry = country; }

std::string RescueAnimal::getTrainingStatus() const { return trainingStatus; }
void RescueAnimal::setTrainingStatus(const std::string& status) { trainingStatus = status; }

bool RescueAnimal::isReserved() const { return reserved; }
void RescueAnimal::setReserved(bool r) { reserved = r; }

std::string RescueAnimal::getInServiceCountry() const { return inServiceCountry; }
void RescueAnimal::setInServiceCountry(const std::string& country) { inServiceCountry = country; }