#ifndef MONKEY_H
#define MONKEY_H

#include "RescueAnimal.h"

class Monkey : public RescueAnimal {
private:
    std::string species;

public:
    Monkey(const std::string& n, const std::string& s, const std::string& g, const std::string& a, const std::string& w,
           const std::string& date, const std::string& country, const std::string& status, bool r, const std::string& serviceCountry);

    std::string getSpecies() const;
    void setSpecies(const std::string& s);
};

#endif

