#ifndef DATABASEHELPER_H
#define DATABASEHELPER_H

#include <string>
#include <vector>
#include "sqlite3.h"
#include "Dog.h"
#include "Monkey.h"

/*
 * DatabaseHelper is a class that encapsulates the functionality
 * required to interact with an SQLite database. It provides methods
 * for opening/closing the database, creating tables, inserting records,
 * and retrieving data.
 */
class DatabaseHelper {
public:
    // Constructor takes the database file name
    DatabaseHelper(const std::string& dbName);
    // Destructor ensures the database is properly closed
    ~DatabaseHelper();

    // Opens the database connection. Returns true if successful.
    bool open();
    // Closes the database connection.
    void close();

    // Creates the necessary tables (dogs and monkeys) if they do not exist.
    bool createTables();
    // Inserts a Dog object into the dogs table.
    bool insertDog(const Dog& dog);
    // Inserts a Monkey object into the monkeys table.
    bool insertMonkey(const Monkey& monkey);
    // Retrieves all Dog records from the database and returns them as a vector.
    std::vector<Dog> getAllDogs();
    // Retrieves all Monkey records from the database and returns them as a vector.
    std::vector<Monkey> getAllMonkeys();

private:
    std::string databaseName; // The SQLite database file name
    sqlite3* db;              // Pointer to the SQLite database connection
};

#endif
