#include <iostream>
#include <vector>
#include "Dog.h"
#include "Monkey.h"

std::vector<Dog> dogList;
std::vector<Monkey> monkeyList;

void initializeDogList() {
    // Initialize list with some examples to test functionality
    dogList.push_back(Dog("Spot", "German Shepherd", "male", "1", "25.6", "05-12-2019", "United States", "in service", false, "United States"));
    dogList.push_back(Dog("Rex", "Great Dane", "male", "3", "35.2", "02-03-2020", "United States", "Phase I", false, "United States"));
    dogList.push_back(Dog("Bella", "Chihuahua", "female", "4", "25.6", "12-12-2019", "Canada", "in service", true, "Canada"));
}

void initializeMonkeyList() {
    // Initialize list with some examples to test functionality
    monkeyList.push_back(Monkey("George", "Capuchin", "male", "2", "12.5", "03-15-2021", "Brazil", "in training", false, "United States"));
    monkeyList.push_back(Monkey("Momo", "Squirrel Monkey", "female", "1", "8.7", "06-10-2022", "Peru", "intake", false, "Canada"));
    monkeyList.push_back(Monkey("Jeff", "Chimpanzee", "male", "1", "14.7", "08-12-2024", "Chile", "in service", false, "Canada"));
}

void intakeNewDog() {
    std::cin.ignore(); // Clear input buffer
    std::string name;
    std::cout << "What is the dog's name? ";
    std::getline(std::cin, name);

    for (const Dog& dog : dogList) {
        if (dog.getName() == name) {
            std::cout << "\n\nThis dog is already in our system\n\n";
            return;
        }
    }

    std::string breed, gender, age, weight, acquisitionDate, acquisitionCountry, trainingStatus;
    bool reserved;

    std::cout << "Enter breed: ";
    std::getline(std::cin, breed);
    std::cout << "Enter gender: ";
    std::getline(std::cin, gender);
    std::cout << "Enter age: ";
    std::getline(std::cin, age);
    std::cout << "Enter weight: ";
    std::getline(std::cin, weight);
    std::cout << "Enter acquisition date: ";
    std::getline(std::cin, acquisitionDate);
    std::cout << "Enter acquisition country: ";
    std::getline(std::cin, acquisitionCountry);
    std::cout << "Enter training status: ";
    std::getline(std::cin, trainingStatus);
    std::cout << "Is the dog reserved? (1 for yes, 0 for no): ";
    std::cin >> reserved;

    dogList.push_back(Dog(name, breed, gender, age, weight, acquisitionDate, acquisitionCountry, trainingStatus, reserved, acquisitionCountry));
    std::cout << "\nDog added successfully!\n";
}

void intakeNewMonkey() {
    std::cin.ignore(); // Clear input buffer
    std::string name;
    std::cout << "What is the monkey's name? ";
    std::getline(std::cin, name);

    for (const Monkey& monkey : monkeyList) {
        if (monkey.getName() == name) {
            std::cout << "\n\nThis monkey is already in our system\n\n";
            return;
        }
    }

    std::string species, gender, age, weight, acquisitionDate, acquisitionCountry, trainingStatus;
    bool reserved;

    std::cout << "Enter species: ";
    std::getline(std::cin, species);
    std::cout << "Enter gender: ";
    std::getline(std::cin, gender);
    std::cout << "Enter age: ";
    std::getline(std::cin, age);
    std::cout << "Enter weight: ";
    std::getline(std::cin, weight);
    std::cout << "Enter acquisition date: ";
    std::getline(std::cin, acquisitionDate);
    std::cout << "Enter acquisition country: ";
    std::getline(std::cin, acquisitionCountry);
    std::cout << "Enter training status: ";
    std::getline(std::cin, trainingStatus);
    std::cout << "Is the monkey reserved? (1 for yes, 0 for no): ";
    std::cin >> reserved;

    monkeyList.push_back(Monkey(name, species, gender, age, weight, acquisitionDate, acquisitionCountry, trainingStatus, reserved, acquisitionCountry));
    std::cout << "\nMonkey added successfully!\n";
}

void printAnimals(const std::string& listType) {
    if (listType == "dog") {
        for (const Dog& dog : dogList) {
            std::cout << "Name: " << dog.getName() << ", Status: " << dog.getTrainingStatus()
                      << ", Country: " << dog.getAcquisitionCountry() << ", Reserved: " << (dog.isReserved() ? "Yes" : "No") << std::endl;
        }
    } else if (listType == "monkey") {
        for (const Monkey& monkey : monkeyList) {
            std::cout << "Name: " << monkey.getName() << ", Status: " << monkey.getTrainingStatus()
                      << ", Country: " << monkey.getAcquisitionCountry() << ", Reserved: " << (monkey.isReserved() ? "Yes" : "No") << std::endl;
        }
    } else if (listType == "available") {
        std::cout << "Available Animals:\n";
        for (const Dog& dog : dogList) {
            if (dog.getTrainingStatus() == "in service" && !dog.isReserved()) {
                std::cout << "Dog - Name: " << dog.getName() << ", Country: " << dog.getAcquisitionCountry() << std::endl;
            }
        }
        for (const Monkey& monkey : monkeyList) {
            if (monkey.getTrainingStatus() == "in service" && !monkey.isReserved()) {
                std::cout << "Monkey - Name: " << monkey.getName() << ", Country: " << monkey.getAcquisitionCountry() << std::endl;
            }
        }
    } else {
        std::cout << "Invalid list type." << std::endl;
    }
}

void displayMenu() {
    std::cout << "\n\nRescue Animal System Menu\n";
    std::cout << "[1] Intake a new dog\n";
    std::cout << "[2] Intake a new monkey\n";
    std::cout << "[3] Reserve an animal\n";
    std::cout << "[4] Print a list of all dogs\n";
    std::cout << "[5] Print a list of all monkeys\n";
    std::cout << "[6] Print a list of all animals that are not reserved\n";
    std::cout << "[q] Quit application\n";
    std::cout << "Enter a menu selection: ";
}

int main() {
    initializeDogList();
    initializeMonkeyList();

    char selection;
    do {
        displayMenu();
        std::cin >> selection;

        switch (selection) {
            case '1':
                intakeNewDog();
                break;
            case '2':
                intakeNewMonkey();
                break;
            case '3':
                std::cout << "Reserve an animal functionality not implemented yet.\n";
                break;
            case '4':
                printAnimals("dog");
                break;
            case '5':
                printAnimals("monkey");
                break;
            case '6':
                printAnimals("available");
                break;
            case 'q':
                std::cout << "Exiting application.\n";
                break;
            default:
                std::cout << "Invalid selection. Please try again.\n";
        }
    } while (selection != 'q');

    return 0;
}