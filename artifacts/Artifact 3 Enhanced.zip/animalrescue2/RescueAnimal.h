// RescueAnimal.h
#ifndef RESCUE_ANIMAL_H
#define RESCUE_ANIMAL_H

#include <string>

class RescueAnimal {
protected:
    std::string name;
    std::string animalType;
    std::string gender;
    std::string age;
    std::string weight;
    std::string acquisitionDate;
    std::string acquisitionCountry;
    std::string trainingStatus;
    bool reserved;
    std::string inServiceCountry;

public:
    RescueAnimal() : reserved(false) {}

    std::string getName() const;
    void setName(const std::string& n);

    std::string getAnimalType() const;
    void setAnimalType(const std::string& type);

    std::string getGender() const;
    void setGender(const std::string& g);

    std::string getAge() const;
    void setAge(const std::string& a);

    std::string getWeight() const;
    void setWeight(const std::string& w);

    std::string getAcquisitionDate() const;
    void setAcquisitionDate(const std::string& date);

    std::string getAcquisitionCountry() const;
    void setAcquisitionCountry(const std::string& country);

    std::string getTrainingStatus() const;
    void setTrainingStatus(const std::string& status);

    bool isReserved() const;
    void setReserved(bool r);

    std::string getInServiceCountry() const;
    void setInServiceCountry(const std::string& country);
};

#endif
