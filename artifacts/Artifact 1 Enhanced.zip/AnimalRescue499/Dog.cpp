#include "Dog.h"

Dog::Dog(const std::string& n, const std::string& b, const std::string& g, const std::string& a, const std::string& w,
         const std::string& date, const std::string& country, const std::string& status, bool r, const std::string& serviceCountry) {
    setName(n);
    setBreed(b);
    setGender(g);
    setAge(a);
    setWeight(w);
    setAcquisitionDate(date);
    setAcquisitionCountry(country);
    setTrainingStatus(status);
    setReserved(r);
    setInServiceCountry(serviceCountry);
}

std::string Dog::getBreed() const { return breed; }
void Dog::setBreed(const std::string& b) { breed = b; }
