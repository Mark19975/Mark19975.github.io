#include <iostream>
#include <vector>
#include "Dog.h"
#include "Monkey.h"
#include "DatabaseHelper.h"

// Global vectors to store Dog and Monkey objects.
std::vector<Dog> dogList;
std::vector<Monkey> monkeyList;

// Forward declarations
void initializeDogList();
void initializeMonkeyList();
void displayMenu();
void handleUserInput(DatabaseHelper& dbHelper);

void displayMenu() {
    std::cout << "\n\nRescue Animal System Menu\n";
    std::cout << "[1] Intake a new dog\n";
    std::cout << "[2] Intake a new monkey\n";
    std::cout << "[3] Reserve an animal\n";
    std::cout << "[4] Print a list of all dogs\n";
    std::cout << "[5] Print a list of all monkeys\n";
    std::cout << "[q] Quit application\n";
    std::cout << "Enter a menu selection: ";
}

int main() {
    initializeDogList();
    initializeMonkeyList();

    DatabaseHelper dbHelper("AnimalRescue.db");
    if (!dbHelper.open()) {
        std::cerr << "Failed to open database." << std::endl;
        return 1;
    }
    if (!dbHelper.createTables()) {
        std::cerr << "Failed to create tables." << std::endl;
        return 1;
    }

    for (const Dog& dog : dogList) {
        dbHelper.insertDog(dog);
    }
    for (const Monkey& monkey : monkeyList) {
        dbHelper.insertMonkey(monkey);
    }

    handleUserInput(dbHelper);

    dbHelper.close();
    return 0;
}

void handleUserInput(DatabaseHelper& dbHelper) {
    char choice;
    do {
        displayMenu();
        std::cin >> choice;
        std::cin.ignore();

        switch (choice) {
        case '1': {
            std::string name, breed, gender, age, weight, acquisitionDate, acquisitionLocation, trainingStatus, reservedLocation;
            bool reserved;

            std::cout << "Enter dog's name: "; std::getline(std::cin, name);
            std::cout << "Enter breed: "; std::getline(std::cin, breed);
            std::cout << "Enter gender: "; std::getline(std::cin, gender);
            std::cout << "Enter age: "; std::getline(std::cin, age);
            std::cout << "Enter weight: "; std::getline(std::cin, weight);
            std::cout << "Enter acquisition date: "; std::getline(std::cin, acquisitionDate);
            std::cout << "Enter acquisition location: "; std::getline(std::cin, acquisitionLocation);
            std::cout << "Enter training status: "; std::getline(std::cin, trainingStatus);
            std::cout << "Is reserved (1 for yes, 0 for no): "; std::cin >> reserved;
            std::cin.ignore();
            std::cout << "Enter reserved location: "; std::getline(std::cin, reservedLocation);

            Dog newDog(name, breed, gender, age, weight, acquisitionDate, acquisitionLocation, trainingStatus, reserved, reservedLocation);
            dbHelper.insertDog(newDog);
            std::cout << "Dog added successfully!\n";
            break;
        }
        case '2': {
            std::string name, species, gender, age, weight, acquisitionDate, acquisitionLocation, trainingStatus, reservedLocation;
            bool reserved;

            std::cout << "Enter monkey's name: "; std::getline(std::cin, name);
            std::cout << "Enter species: "; std::getline(std::cin, species);
            std::cout << "Enter gender: "; std::getline(std::cin, gender);
            std::cout << "Enter age: "; std::getline(std::cin, age);
            std::cout << "Enter weight: "; std::getline(std::cin, weight);
            std::cout << "Enter acquisition date: "; std::getline(std::cin, acquisitionDate);
            std::cout << "Enter acquisition location: "; std::getline(std::cin, acquisitionLocation);
            std::cout << "Enter training status: "; std::getline(std::cin, trainingStatus);
            std::cout << "Is reserved (1 for yes, 0 for no): "; std::cin >> reserved;
            std::cin.ignore();
            std::cout << "Enter reserved location: "; std::getline(std::cin, reservedLocation);

            Monkey newMonkey(name, species, gender, age, weight, acquisitionDate, acquisitionLocation, trainingStatus, reserved, reservedLocation);
            dbHelper.insertMonkey(newMonkey);
            std::cout << "Monkey added successfully!\n";
            break;
        }
        case '4': {
            std::vector<Dog> dbDogs = dbHelper.getAllDogs();
            std::cout << "\nDogs in database:" << std::endl;
            for (const Dog& d : dbDogs) {
                std::cout << d.getName() << " - " << d.getBreed() << " - " << d.getGender() << " - " << d.getAge() << " - " << d.getWeight() 
                    << " - " << d.getAcquisitionDate() << " - " << d.getAcquisitionCountry() << " - " << d.getTrainingStatus() << " - " 
                    << d.isReserved() << " - " << d.getInServiceCountry() << std::endl;
            }
            break;
        }
        case '5': {
            std::vector<Monkey> monkeys = dbHelper.getAllMonkeys();
            for (const Monkey& m : monkeys) {
                std::cout << m.getName() << " - " << m.getSpecies() << " - " << m.getGender() << " - " << m.getAge() << " - " << m.getWeight() 
                    << " - " << m.getAcquisitionDate() << " - " << m.getAcquisitionCountry() << " - " << m.getTrainingStatus() << " - " 
                    << m.isReserved() << " - " << m.getInServiceCountry() << std::endl;
            }
            break;
        }
        case 'q':
            std::cout << "Exiting program...\n";
            break;
        default:
            std::cout << "Invalid option, please try again.\n";
        }
    } while (choice != 'q');
}

void initializeDogList() {
    dogList.push_back(Dog("Spot", "German Shepherd", "male", "1", "25.6", "05-12-2019", "United States", "intake", false, "United States"));
    dogList.push_back(Dog("Rex", "Great Dane", "male", "3", "35.2", "02-03-2020", "United States", "Phase I", false, "United States"));
    dogList.push_back(Dog("Bella", "Chihuahua", "female", "4", "25.6", "12-12-2019", "Canada", "in service", true, "Canada"));
}

void initializeMonkeyList() {
    monkeyList.push_back(Monkey("George", "Capuchin", "male", "2", "12.5", "03-15-2021", "Brazil", "in training", false, "United States"));
    monkeyList.push_back(Monkey("Momo", "Squirrel Monkey", "female", "1", "8.7", "06-10-2022", "Peru", "intake", false, "Canada"));
}
