#include "DatabaseHelper.h"
#include <iostream>

// Constructor: Initializes the database name and sets the database pointer to nullptr.
DatabaseHelper::DatabaseHelper(const std::string& dbName) : databaseName(dbName), db(nullptr) {}

// Destructor: Ensures that the database is closed when the object is destroyed.
DatabaseHelper::~DatabaseHelper() {
    close();
}

// Opens the SQLite database using the provided database name.
bool DatabaseHelper::open() {
    int rc = sqlite3_open(databaseName.c_str(), &db);
    if (rc) {
        std::cerr << "Can't open database: " << sqlite3_errmsg(db) << std::endl;
        return false;
    }
    return true;
}

// Closes the SQLite database connection.
void DatabaseHelper::close() {
    if (db) {
        sqlite3_close(db);
        db = nullptr;
    }
}

// Creates the necessary tables for dogs and monkeys in the database.
// Uses IF NOT EXISTS to avoid errors if the tables are already created.
bool DatabaseHelper::createTables() {
    const char* sqlDogs = "CREATE TABLE IF NOT EXISTS dogs ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT, "
        "name TEXT NOT NULL, "
        "breed TEXT NOT NULL, "
        "gender TEXT NOT NULL, "
        "age TEXT NOT NULL, "
        "weight TEXT NOT NULL, "
        "acquisitionDate TEXT NOT NULL, "
        "acquisitionCountry TEXT NOT NULL, "
        "trainingStatus TEXT NOT NULL, "
        "reserved INTEGER NOT NULL, "
        "inServiceCountry TEXT NOT NULL);";

    const char* sqlMonkeys = "CREATE TABLE IF NOT EXISTS monkeys ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT, "
        "name TEXT NOT NULL, "
        "species TEXT NOT NULL, "
        "gender TEXT NOT NULL, "
        "age TEXT NOT NULL, "
        "weight TEXT NOT NULL, "
        "acquisitionDate TEXT NOT NULL, "
        "acquisitionCountry TEXT NOT NULL, "
        "trainingStatus TEXT NOT NULL, "
        "reserved INTEGER NOT NULL, "
        "inServiceCountry TEXT NOT NULL);";

    char* errMsg = nullptr;
    int rc = sqlite3_exec(db, sqlDogs, nullptr, nullptr, &errMsg);
    if (rc != SQLITE_OK) {
        std::cerr << "SQL error (dogs): " << errMsg << std::endl;
        sqlite3_free(errMsg);
        return false;
    }

    rc = sqlite3_exec(db, sqlMonkeys, nullptr, nullptr, &errMsg);
    if (rc != SQLITE_OK) {
        std::cerr << "SQL error (monkeys): " << errMsg << std::endl;
        sqlite3_free(errMsg);
        return false;
    }
    return true;
}

// Inserts a Dog object into the dogs table. Binds each attribute to the SQL statement.
bool DatabaseHelper::insertDog(const Dog& dog) {
    std::string sql = "INSERT INTO dogs (name, breed, gender, age, weight, acquisitionDate, acquisitionCountry, trainingStatus, reserved, inServiceCountry) VALUES (?,?,?,?,?,?,?,?,?,?);";
    sqlite3_stmt* stmt;
    int rc = sqlite3_prepare_v2(db, sql.c_str(), -1, &stmt, nullptr);
    if (rc != SQLITE_OK) {
        std::cerr << "Cannot prepare statement: " << sqlite3_errmsg(db) << std::endl;
        return false;
    }
    // Bind the Dog object's attributes to the SQL statement parameters.
    sqlite3_bind_text(stmt, 1, dog.getName().c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 2, dog.getBreed().c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 3, dog.getGender().c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 4, dog.getAge().c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 5, dog.getWeight().c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 6, dog.getAcquisitionDate().c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 7, dog.getAcquisitionCountry().c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 8, dog.getTrainingStatus().c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 9, dog.isReserved() ? 1 : 0);
    sqlite3_bind_text(stmt, 10, dog.getInServiceCountry().c_str(), -1, SQLITE_TRANSIENT);

    rc = sqlite3_step(stmt);
    if (rc != SQLITE_DONE) {
        std::cerr << "Execution failed: " << sqlite3_errmsg(db) << std::endl;
        sqlite3_finalize(stmt);
        return false;
    }
    else {
        std::cout << "Dog inserted successfully: " << dog.getName() << std::endl;
    }
    sqlite3_finalize(stmt);
    return rc == SQLITE_DONE;
}

// Inserts a Monkey object into the monkeys table.
bool DatabaseHelper::insertMonkey(const Monkey& monkey) {
    std::string sql = "INSERT INTO monkeys (name, species, gender, age, weight, acquisitionDate, acquisitionCountry, trainingStatus, reserved, inServiceCountry) VALUES (?,?,?,?,?,?,?,?,?,?);";
    sqlite3_stmt* stmt;
    int rc = sqlite3_prepare_v2(db, sql.c_str(), -1, &stmt, nullptr);
    if (rc != SQLITE_OK) {
        std::cerr << "Cannot prepare statement: " << sqlite3_errmsg(db) << std::endl;
        return false;
    }
    // Bind the Monkey object's attributes to the SQL statement parameters.
    sqlite3_bind_text(stmt, 1, monkey.getName().c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 2, monkey.getSpecies().c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 3, monkey.getGender().c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 4, monkey.getAge().c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 5, monkey.getWeight().c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 6, monkey.getAcquisitionDate().c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 7, monkey.getAcquisitionCountry().c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 8, monkey.getTrainingStatus().c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 9, monkey.isReserved() ? 1 : 0);
    sqlite3_bind_text(stmt, 10, monkey.getInServiceCountry().c_str(), -1, SQLITE_TRANSIENT);

    rc = sqlite3_step(stmt);
    if (rc != SQLITE_DONE) {
        std::cerr << "Execution failed: " << sqlite3_errmsg(db) << std::endl;
        sqlite3_finalize(stmt);
        return false;
    }
    sqlite3_finalize(stmt);
    return true;
}

// Retrieves all Dog records from the database and returns them as a vector of Dog objects.
std::vector<Dog> DatabaseHelper::getAllDogs() {
    std::vector<Dog> dogs;
    std::string sql = "SELECT name, breed, gender, age, weight, acquisitionDate, acquisitionCountry, trainingStatus, reserved, inServiceCountry FROM dogs;";
    sqlite3_stmt* stmt;
    int rc = sqlite3_prepare_v2(db, sql.c_str(), -1, &stmt, nullptr);
    if (rc != SQLITE_OK) {
        std::cerr << "Failed to prepare statement in getAllDogs: " << sqlite3_errmsg(db) << std::endl;
        return dogs;
    }

    // Iterate through each row returned by the query.
    while ((rc = sqlite3_step(stmt)) == SQLITE_ROW) {
        std::string name = (sqlite3_column_text(stmt, 0)) ? reinterpret_cast<const char*>(sqlite3_column_text(stmt, 0)) : "-";
        std::string breed = (sqlite3_column_text(stmt, 1)) ? reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1)) : "-";
        std::string gender = (sqlite3_column_text(stmt, 2)) ? reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2)) : "-";
        std::string age = (sqlite3_column_text(stmt, 3)) ? reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3)) : "-";
        std::string weight = (sqlite3_column_text(stmt, 4)) ? reinterpret_cast<const char*>(sqlite3_column_text(stmt, 4)) : "-";
        std::string acquisitionDate = (sqlite3_column_text(stmt, 5)) ? reinterpret_cast<const char*>(sqlite3_column_text(stmt, 5)) : "-";
        std::string acquisitionCountry = (sqlite3_column_text(stmt, 6)) ? reinterpret_cast<const char*>(sqlite3_column_text(stmt, 6)) : "-";
        std::string trainingStatus = (sqlite3_column_text(stmt, 7)) ? reinterpret_cast<const char*>(sqlite3_column_text(stmt, 7)) : "-";
        bool reserved = sqlite3_column_int(stmt, 8) == 1;
        std::string inServiceCountry = (sqlite3_column_text(stmt, 9)) ? reinterpret_cast<const char*>(sqlite3_column_text(stmt, 9)) : "-";

        dogs.emplace_back(name, breed, gender, age, weight, acquisitionDate, acquisitionCountry, trainingStatus, reserved, inServiceCountry);
    }

    sqlite3_finalize(stmt);
    return dogs;
}

// Retrieves all Monkey records from the database and returns them as a vector of Monkey objects.
std::vector<Monkey> DatabaseHelper::getAllMonkeys() {
    std::vector<Monkey> monkeys;
    std::string sql = "SELECT name, species, gender, age, weight, acquisitionDate, acquisitionCountry, trainingStatus, reserved, inServiceCountry FROM monkeys;";
    sqlite3_stmt* stmt;
    int rc = sqlite3_prepare_v2(db, sql.c_str(), -1, &stmt, nullptr);
    if (rc != SQLITE_OK) {
        std::cerr << "Failed to prepare statement in getAllMonkeys: " << sqlite3_errmsg(db) << std::endl;
        return monkeys;
    }

    while ((rc = sqlite3_step(stmt)) == SQLITE_ROW) {
        std::string name = (sqlite3_column_text(stmt, 0)) ? reinterpret_cast<const char*>(sqlite3_column_text(stmt, 0)) : "-";
        std::string species = (sqlite3_column_text(stmt, 1)) ? reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1)) : "-";
        std::string gender = (sqlite3_column_text(stmt, 2)) ? reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2)) : "-";
        std::string age = (sqlite3_column_text(stmt, 3)) ? reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3)) : "-";
        std::string weight = (sqlite3_column_text(stmt, 4)) ? reinterpret_cast<const char*>(sqlite3_column_text(stmt, 4)) : "-";
        std::string acquisitionDate = (sqlite3_column_text(stmt, 5)) ? reinterpret_cast<const char*>(sqlite3_column_text(stmt, 5)) : "-";
        std::string acquisitionCountry = (sqlite3_column_text(stmt, 6)) ? reinterpret_cast<const char*>(sqlite3_column_text(stmt, 6)) : "-";
        std::string trainingStatus = (sqlite3_column_text(stmt, 7)) ? reinterpret_cast<const char*>(sqlite3_column_text(stmt, 7)) : "-";
        bool reserved = sqlite3_column_int(stmt, 8) == 1;
        std::string inServiceCountry = (sqlite3_column_text(stmt, 9)) ? reinterpret_cast<const char*>(sqlite3_column_text(stmt, 9)) : "-";

        monkeys.emplace_back(name, species, gender, age, weight, acquisitionDate, acquisitionCountry, trainingStatus, reserved, inServiceCountry);
    }

    sqlite3_finalize(stmt);
    return monkeys;
}
