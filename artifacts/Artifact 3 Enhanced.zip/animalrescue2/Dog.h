#ifndef DOG_H
#define DOG_H

#include "RescueAnimal.h"

class Dog : public RescueAnimal {
private:
    std::string breed;

public:
    Dog(const std::string& n, const std::string& b, const std::string& g, const std::string& a, const std::string& w,
        const std::string& date, const std::string& country, const std::string& status, bool r, const std::string& serviceCountry);

    std::string getBreed() const;
    void setBreed(const std::string& b);
};

#endif
